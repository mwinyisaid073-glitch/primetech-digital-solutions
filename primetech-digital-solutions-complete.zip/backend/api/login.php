<?php
header('Content-Type: application/json');
require 'config.php';
$data = json_decode(file_get_contents('php://input'), true);
$username = trim($data['username'] ?? '');
$password = $data['password'] ?? '';
$stmt = $pdo->prepare('SELECT id, username, password_hash, role FROM users WHERE username = ? LIMIT 1');
$stmt->execute([$username]);
$user = $stmt->fetch();
if (!$user || !password_verify($password, $user['password_hash'])) {
    http_response_code(401);
    echo json_encode(['success'=>false,'message'=>'Invalid username or password']);
    exit;
}
echo json_encode(['success'=>true,'user'=>['id'=>$user['id'],'username'=>$user['username'],'role'=>$user['role']]]);
?>