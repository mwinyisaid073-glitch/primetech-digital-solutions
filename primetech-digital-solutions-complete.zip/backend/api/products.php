<?php
header('Content-Type: application/json');
require 'config.php';
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $stmt=$pdo->query('SELECT id,name,category,price,stock FROM products ORDER BY id DESC');
    echo json_encode($stmt->fetchAll());
    exit;
}
$data=json_decode(file_get_contents('php://input'),true);
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $stmt=$pdo->prepare('INSERT INTO products(name,category,price,stock) VALUES(?,?,?,?)');
    $stmt->execute([$data['name']??'', $data['category']??'', $data['price']??0, $data['stock']??0]);
    echo json_encode(['success'=>true,'id'=>$pdo->lastInsertId()]);
}
?>